# Quantile-Based-Clustering
This is a Python library for Quantile-based clustering[1].
All four algorithms are implemented.
Download on you pc using $\verb|pip install QuClu.py|$


## Bibliography
[1] Hennig, Christian, Cinzia Viroli, and Laura Anderlucci. "Quantile-based clustering." Electronic Journal of Statistics 13.2 (2019): 4849-4883.
