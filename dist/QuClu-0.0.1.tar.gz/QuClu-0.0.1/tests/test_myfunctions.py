
from QuClu import myfunctions
def test_haversine():
    assert 1==1